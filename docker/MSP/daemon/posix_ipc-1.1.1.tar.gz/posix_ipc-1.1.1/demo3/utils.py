QUEUE_NAME = "/my_message_queue"
